import javax.swing.*;

public class BurmaShave {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "(CN)Shave the modern way");
        JOptionPane.showMessageDialog(null, "(CN)No brush");
        JOptionPane.showMessageDialog(null, "(CN)No lather");
        JOptionPane.showMessageDialog(null, "(CN)No rub-in");
        JOptionPane.showMessageDialog(null, "(CN)Big tube 35 cents – Drug stores");
        JOptionPane.showMessageDialog(null, "(CN)Burma-Shave");
    }
}
