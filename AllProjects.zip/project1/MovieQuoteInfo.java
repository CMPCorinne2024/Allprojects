public class MovieQuoteInfo {
    public static void main(String[] args) {
        System.out.println("Corinne Nogacek");
        System.out.println("Quote: For 27 years, I dreamt of you. I craved you... I've missed you!");
        System.out.println("Movie:It chapter two");
        System.out.println("Charater: pennywise");
        System.out.println("Year: 2019");
    }
    }
