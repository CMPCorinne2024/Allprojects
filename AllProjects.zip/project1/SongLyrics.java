public class SongLyrics {
    public static void main(String[] args) {
        System.out.println("Corinne Nogacek");
        System.out.println("Oh-oh, forgiving who you are, for what you stand to gain\n" +
                "Just know that if you hide, it doesn't go away\n" +
                "When you get out of bed, don't end up stranded\n" +
                "Horrified with each stone on the stage, my little dark age");
    }

}
