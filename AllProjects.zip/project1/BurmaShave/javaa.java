package BurmaShave;

public class javaa {
}
