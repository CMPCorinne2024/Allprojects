public class TableAndChairs {
    public static void main(String[] args) {
        System.out.println("Corinne Nogacek");
        System.out.println("x                      x");
        System.out.println("x                      x");
        System.out.println("x      xxxxxxxxxx      x");
        System.out.println("xxxxxx x        x xxxxxx");
        System.out.println("x    x x        x x    x");
        System.out.println("x    x x        x x    x");
    }
    }
