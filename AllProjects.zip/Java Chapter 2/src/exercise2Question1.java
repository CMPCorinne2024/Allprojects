public class exercise2Question1 {
    public static void main(String[] args) {
        int firstNum = 3;
        int secNum = -2;
        int thrdNum = 6;
        int fthNum = 30;
        boolean sum = firstNum + secNum * thrdNum == fthNum;
        System.out.println("the sum is: " + sum);
    }
}
