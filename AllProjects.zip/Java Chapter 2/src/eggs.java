//Corinne Nogacek
//9/8/2023
//#11

import java.util.Scanner;

public class eggs {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        final int eggsInDozen = 12;
        int eggs = 100;
        System.out.println("please enter amount of eggs >> ");
        eggs = input.nextInt();
        int ans1 = eggs/eggsInDozen;
        int ans2 = eggs%eggsInDozen;

        double ans1Price = ans1 * 3.25;
        double ans2Price = ans2 * .45;
        double total = ans1Price + ans2Price;

        System.out.println("You ordered " + eggs + " eggs.");
        System.out.println("Thats " + ans1 + " dozen at $3.25 per dozen and " + ans2 + " loose eggs at $.45 each");
        System.out.println("Total: $" + total);
            }
        }



