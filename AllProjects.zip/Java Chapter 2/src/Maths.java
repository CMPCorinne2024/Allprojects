public class Maths {
    public static void main(String[] args) {
        int firstNum = 5;
        int secondNum = 4;
        int sum = firstNum + secondNum;
        System.out.println("the sum is: " + sum);
        double quotient = (double)sum/2;
        System.out.println("the quotient is:" + quotient);

    }
}
