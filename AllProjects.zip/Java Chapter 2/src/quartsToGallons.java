//Corinne Nogacek
//9/8/2023
//#5

import java.util.Scanner;


public class quartsToGallons {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        final int QUARTSINGAL = 4;
        int qts = 100;
        System.out.println("please enter amount of quarts >> ");
        qts = input.nextInt();

        int ans1 = qts/QUARTSINGAL;
        int ans2 = qts%QUARTSINGAL;
        System.out.println("You need " + ans1 + " gallons and " + ans2 + " quarts");

    }
}
