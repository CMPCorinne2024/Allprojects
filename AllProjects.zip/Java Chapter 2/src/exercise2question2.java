public class exercise2question2 {
    public static void main(String[] args) {

    }
}
