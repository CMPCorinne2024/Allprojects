import java.util.Scanner;

public class IntegerDemoInteractive {
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            int aInt = 2147483647;
            byte aByte = 127;
            short aShort = 32767;
            long aLong = 9223372036854775807L;
            long intMult =  (long) aInt * aByte;
            System.out.println("Please enter an integer >> ");
            aInt = input.nextInt();
            System.out.println("Please enter an byte integer >> ");
            aByte = input.nextByte();
            System.out.println("Please enter a short integer >> ");
            aShort = input.nextShort();
            System.out.println("Please enter a long integer >> ");
            aLong = input.nextLong();

            System.out.println("Value of aInt " + aInt);
            System.out.println("Value of aByte " + aByte);
            System.out.println("Value of aShort " + aShort);
            System.out.println("Value of aLong " + aLong);
            System.out.println("Value of intMult " + intMult);
        }
    }


