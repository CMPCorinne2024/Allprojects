//Corinne Nogacek
//9/11/2023
//#14

import java.util.Scanner;

public class dollars {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter how manny dollars to convert to currency >>");
        int Money = 72;
        Money = input.nextInt();

        int Twenties = Money/20;
        Money = Money%20;
        int Tens = Money/10;
        Money = Money%10;
        int Fives = Money/5;
        Money = Money%5;
        int Ones = Money;





        System.out.println("Twenties: " + Twenties);
        System.out.println("Tens: " + Tens);
        System.out.println("Fives: " + Fives);
        System.out.println("Ones: " + Ones);



    }
}
