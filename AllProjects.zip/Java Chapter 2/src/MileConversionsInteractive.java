//Corinne Nogacek
//9/8/2023
//#7

import java.util.Scanner;

public class MileConversionsInteractive {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int inches = 63360;
        int feet = 5280;
        int yards = 1760;
        int miles = 1000;

        System.out.println("please enter amount of miles >> ");
        miles = input.nextInt();
        System.out.println("Inches in " + miles + " miles = " + inches * miles);
        System.out.println("Feet in " + miles + " miles = " + feet * miles);
        System.out.println("Yards in " + miles + " miles = " + yards * miles);
    }
}


