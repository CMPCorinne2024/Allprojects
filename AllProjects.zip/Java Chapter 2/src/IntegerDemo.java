public class IntegerDemo {
    public static void main(String[] args) {
        int aInt = 2147483647;
        byte aByte = 127;
        short aShort = 32767;
        long aLong = 9223372036854775807L;
        long intMult =  (long) aInt*aByte;
        System.out.println("Value of aInt " + aInt);
        System.out.println("Value of aByte " + aByte);
        System.out.println("Value of aShort " + aShort);
        System.out.println("Value of aLong " + aLong);
        System.out.println("Value of intMult " + intMult);
    }
}
