public class DataDemo {
    public static void main(String[] args) {
        int aWholeNumber;
        aWholeNumber = 315;
        System.out.print("The number is ");
        System.out.println(aWholeNumber);
    }
}
