public class CharDemo {
    public static void main(String[] args) {
        char initial = 'R';
        System.out.println(initial);
        System.out.println("\t\"abc\\def\bghi\n\njkl");
    }
}
