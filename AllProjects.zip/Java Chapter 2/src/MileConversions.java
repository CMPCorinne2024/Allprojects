//Corinne Nogacek
//9/8/2023
//#6

public class MileConversions {
    public static void main(String[] args) {
        int inches = 63360;
        int feet = 5280;
        int yards = 1760;
        int miles = 10;

        System.out.println("Inches in " + miles + " miles = " + inches * miles);
        System.out.println("Feet in " + miles + " miles = " + feet * miles);
        System.out.println("Yards in " + miles + " miles = " + yards * miles);

    }
}
