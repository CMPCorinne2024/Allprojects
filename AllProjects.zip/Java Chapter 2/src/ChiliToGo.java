//Corinne Nogacek
//9/8/2023
//#12

import java.util.Scanner;

public class ChiliToGo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);


        int NumAdults = 10;
        int NumChildren = 10;
        int adultPrice = 7;
        int childPrice = 4;

        System.out.println("Please enter amount of adult meals >> ");
        NumAdults = input.nextInt();
        System.out.println("Please enter amount of children meals >> ");
        NumChildren = input.nextInt();

        int total = (NumAdults * adultPrice) + (NumChildren * childPrice);

        System.out.println("Total: $" + total);

    }
}
