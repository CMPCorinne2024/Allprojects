//Corinne Nogacek & Abby Rogers
//9/12/2023
//#8
import java.util.Scanner;

public class InchesToFeet {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
            int inchesInFeet = 12;
            int inches = 1000;
        System.out.print("Please enter inches to convert to feet >> ");
        inches = input.nextInt();
        int ans1 = inches/inchesInFeet;
        int ans2 = inches%inchesInFeet;

        System.out.println(inches + " Inches = " + ans1 + " feet and " + ans2 +" inches");
    }
}
