public class test {
    public static void main(String[] args) {
        boolean isTenlarger = (10 < 5);
        System.out.println(isTenlarger);
    }
}
