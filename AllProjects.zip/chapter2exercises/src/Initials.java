//Corinne Nogacek & Abby Rogers
//9/12/2023
//#10
import java.util.Scanner;
public class Initials {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        char first = 0;
        char second = 0;
        char last = 0;

        System.out.print("Please enter your first initial >>");
        first = input.next().charAt(0);


        System.out.print("Please enter your second initial >>");
        second = input.next().charAt(0);


        System.out.print("Please enter your last initial >>");
        last = input.next().charAt(0);

        System.out.println(first +"." + second + "." + last + ".");

    }
}
