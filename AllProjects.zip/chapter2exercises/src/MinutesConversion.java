//Corinne Nogacek
//9/12/2023
//#15

import java.util.Scanner;

public class MinutesConversion {
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            int minutesToHours = 60;
            int hoursToDays = 24;
            int minutes = 10000;
            System.out.print("Please enter minutes to convert to hours and days >> ");
            minutes = input.nextInt();
            int ans1 = minutes/minutesToHours;
            int ans2 = minutes%minutesToHours;
            int ans3 = ans1 + ans2;
            int ans4 = ans3/hoursToDays;

            System.out.println(minutes + " minutes = " + ans1 + " hours and " + ans2 +" minutes");
            System.out.print("It also is equal to about " + ans4  + " days");
        }
    }


