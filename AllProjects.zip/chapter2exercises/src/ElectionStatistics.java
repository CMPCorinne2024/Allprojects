//Corinne Nogacek
//9/12/2023
//#16

import java.util.Scanner;

public class ElectionStatistics {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char person1 = 0;
        char person2 = 0;
        char person3 = 0;
        int num1 = 100000000;
        int num2 = 100000000;
        int num3 = 100000000;

        System.out.println("Please enter a polititcal party >> ");
        person1 = input.next().charAt(0);
        System.out.println("please enter their number of votes from the last election");
        num1 = input.nextInt();



        System.out.println("Please enter a polititcal party >> ");
        person2 = input.next().charAt(0);
        System.out.println("please enter their number of votes from the last election");
        num2 = input.nextInt();


        System.out.println("Please enter a polititcal party >> ");
        person3 = input.next().charAt(0);
        System.out.println("please enter their number of votes from the last election");
        num3 = input.nextInt();

        double all3 = num1 + num2 + num3;
        double percent1 = (num1 / all3) * 100;
        double percent2 = (num2 / all3) * 100;
        double percent3 = (num3 / all3) * 100;

        System.out.println("Percent of the vote for " + person1 + " = " + percent1 + "%");
        System.out.println("Percent of the vote for " + person2 + " = " + percent2 + "%");
        System.out.println("Percent of the vote for " + person3 + " = " + percent3 + "%");
    }
}
