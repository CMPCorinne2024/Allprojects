public class SpaScervice {
    private String serviceDesc;
    private double price;
    public void setServiceDesc(String service){
        serviceDesc = service;
    }
    public String getServiceDesc(){
        return serviceDesc;
    }
    public void setPrice(double price){
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public SpaScervice(){
        serviceDesc = "deep tissue massage";
        price = 5;
    }

    public SpaScervice(double price, String desc){
        this.price = price;
        this.serviceDesc = desc;
    }
}
