public class ParadiseInfo {
    public static void main(String[] args) {
        DisplayInfo();
    }

    public static void DisplayInfo(){
        System.out.println("Paradise Day Spa want to paper you.");
        System.out.println("We can even make Mr. Klins look good.");
    }
}
