import java.util.Scanner;

public class CreateSpaServices {
    public static void main(String[] args) {
        String service;
        double price;
        Scanner keyboard = new Scanner(System.in);
        SpaScervice firstService = new SpaScervice();
        SpaScervice secondService = new SpaScervice(5.99, "deep tissue masage");

        //PopulateService(keyboard, firstService);
        //PopulateService(keyboard, secondService);

        PrintService("First", firstService);
        PrintService("Second", secondService);

    }

    public static void PopulateService(Scanner keyboard, SpaScervice ss){
        System.out.print("Enter service >> ");
        String service = keyboard.nextLine();
        System.out.print("Enter price >> ");
        double price = keyboard.nextDouble();
        ss.setServiceDesc(service);
        ss.setPrice(price);
        keyboard.nextLine();
    }

    public static void PrintService(String service_num, SpaScervice sp) {
        System.out.println("First Service Details:");
        System.out.printf(sp.getServiceDesc() + " $%.2f", sp.getPrice());
        System.out.println();
    }
}


