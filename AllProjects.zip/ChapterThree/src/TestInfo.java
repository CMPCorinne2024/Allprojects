public class TestInfo {
    public static void main(String[] args) {
        ParadiseInfo.DisplayInfo();
    }
}
