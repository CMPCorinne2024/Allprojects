public class Num1 {
    public static void main(String[] args) {
        Bicycle myBike = new Bicycle();
/*
        myBike.height = 26;

        myBike.model = "Cyclone";

        myBike.wheels = 3;

        myBike.model = 108;

        Bicycle.height = 24;

        Bicycle.model = "Hurricane";

        Bicycle.int = 3;

        Bicycle.model = 108;

        Bicycle.wheels = 2;

        Bicycle yourBike = myBike;
*/

    }
}
