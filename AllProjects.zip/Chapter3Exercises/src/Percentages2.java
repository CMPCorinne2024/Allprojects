import java.util.Scanner;

public class Percentages2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double one = 10;
        double two = 15;

        System.out.println("Enter your first number >> " );
        one = input.nextInt();

        System.out.println("Enter your second number >> ");
        two = input.nextInt();


        computePercent(one, two);
    }

    public static void computePercent(double num1, double num2){
        System.out.println((num1/num2) * 100 + "%");
    }
}
