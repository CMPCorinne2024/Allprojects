import java.util.Scanner;


public class NumbersDemo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int x = 5;
        int y = 13;

        System.out.print("Enter a value for x >> ");
        x = input.nextInt();

        System.out.print("Enter a value for y >> ");
        y = input.nextInt();


        System.out.println("The numbers multiplied by 2: ");
        displayTwiceTheNumber(x);
        displayTwiceTheNumber(y);
        System.out.println("The numbers with 5 added: ");
        displayNumberPlusFive(x);
        displayNumberPlusFive(y);
        System.out.println("The numbers squared");
        displayNumberSquared(x);
        displayNumberSquared(y);
    }
     public static void displayTwiceTheNumber(int num){
         System.out.println(num * 2);
     }

     public static void displayNumberPlusFive(int num){
         System.out.println(num + 5);
     }

    public static void displayNumberSquared(int num){
        System.out.println(num * num);
    }
}
