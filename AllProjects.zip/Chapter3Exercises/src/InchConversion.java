import java.util.Scanner;

public class InchConversion {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int inches;

        System.out.println("Enter a number of inches you would like to convert >>");
        inches = input.nextInt();

        System.out.print("Feet:");inchesToFeet(inches);
        System.out.print("Yard(s):");inchesToYards(inches);

    }

    public static void inchesToFeet(int num) {
        System.out.println(num / 12);
    }

    public static void inchesToYards(int num) {
        System.out.println(num / 36);
    }
}
