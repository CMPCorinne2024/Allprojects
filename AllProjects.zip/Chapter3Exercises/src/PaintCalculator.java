import java.util.Scanner;

public class PaintCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int length;
        int width;
        int height;

        System.out.println("Please enter the legth of your room >> ");
        length = input.nextInt();

        System.out.println("Please enter the width of your room >> ");
        width = input.nextInt();

        System.out.println("Please enter the height of your room >> ");
        height = input.nextInt();

        int area = (length + width) * 2 * height;
        int price = PaintNeeded(area) * 32;


        System.out.print("Gallons needed: ");
        PaintNeeded(area);
        System.out.println("Cost of paint: $" + price);


    }

    public static int PaintNeeded(int num) {
        System.out.println(num / 350);
        return num/350;
    }

}
