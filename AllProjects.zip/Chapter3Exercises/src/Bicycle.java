public class Bicycle {
    private int height;
    public String model;
    public static int wheels;
}
