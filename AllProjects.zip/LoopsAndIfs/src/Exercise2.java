public class Exercise2 {
    public static void main(String[] args) {
        multiply(5);
    }

    public static void multiply(int num) {
        int i = 1;
        while (i <= num) {
            for (int j = 1; j <= i; j++) {
                System.out.println(num + " * " + j  + " = ");
            }
            System.out.println();
            i++;
        }
    }
}
