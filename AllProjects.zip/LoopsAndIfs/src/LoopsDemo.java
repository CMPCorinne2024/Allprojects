public class LoopsDemo {
    public static void main(String[] args) {
        countToTenForLoop();
        countToNumForLoop(50);
        whileLessThan20CountThemAll();
        evenOrOdd(9);
        evenOrOdd(4);
        evenOrOdd(10);
        evenOrOdd(420);
    }

    public static void countToTenForLoop() {
        System.out.println("Counting to 10");
        for (int i = 0; i <= 10; i++) {
            System.out.println(i);
        }
    }

    public static void countToNumForLoop(int aNum) {
        System.out.println("Counting to " + aNum);
        for (int i = 0; i <= aNum; i++) {
            System.out.println(i);
        }
    }
    public static void whileLessThan20CountThemAll() {
        int i = 10;
        while (i < 20) {
            System.out.println(i);
            i++;
            for(int j = 1; j <= i; j++){
                System.out.println(j + " ");
            }
            System.out.println();
            i++;
        }
    }

    public static void evenOrOdd(int num) {
        System.out.println("I'm going to check out this hot num: " + num);
        if(num % 2 == 1 || num == 420){//NOTICE || or OR
            System.out.println("It's odd!..or somptin'");
        }else if(40 % num == 0 && num < 10){//NOTICE && for AND
            System.out.println("It's super awesome and even! :)");
        }else{
            System.out.println("I'ts even :/");
        }
    }
}



