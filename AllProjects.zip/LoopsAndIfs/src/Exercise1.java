public class Exercise1 {
    public static void main(String[] args) {
        Stars(5);
    }

        public static void Stars(int num){
        if(num <= 0){
            System.out.println("That number is too small");
            }else {
            int i = 1;
            while (i <= num) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
                i++;
            }
        }
        }
    }



