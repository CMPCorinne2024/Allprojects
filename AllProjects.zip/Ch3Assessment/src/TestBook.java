public class TestBook {
    public static void main(String[] args) {
    Book b1 = new Book();
    Book b2 = new Book();
    b1.setBookTitle("Ishmael: A Novel");
    b1.setAuthorName("Daniel Quinn");
    b1.setPageCount(263);
    b1.setPrice(11.69);

    b2.setBookTitle("The Berenstain Bears and the Blame Game");
    b2.setAuthorName("Stan and Jan Barenstain");
    b2.setPageCount(32);
    b2.setPrice(4.99);

    printBook(b1);
    printBook(b2);
    }

    public static void printBook(Book b){
        System.out.println(b.getBookTitle() + " " + b.getAuthorName() + " " + b.getPageCount() + " " + b.getPrice());
    }
}
