public class Book {
        private String bookTitle;
        private String authorName;
        private int pageCount;
        private double price;

        public String getAuthorName() {
                return authorName;
        }

        public void setAuthorName(String authorName) {
                this.authorName = authorName;
        }

        public String getBookTitle() {
                return bookTitle;
        }

        public void setBookTitle(String bookTitle) {
                this.bookTitle = bookTitle;
        }

        public int getPageCount() {
                return pageCount;
        }

        public void setPageCount(int pageCount) {
                this.pageCount = pageCount;
        }

        public double getPrice() {
                return price;
        }

        public void setPrice(double price) {
                this.price = price;
        }




}
